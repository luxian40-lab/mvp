echo "Ejecutando migraciones Django..."
echo "Recolectando archivos estáticos..."
echo "Post-deploy completado."

# Script deshabilitado para despliegue Docker EB
# echo "Ejecutando migraciones Django..."
# python3 manage.py migrate --noinput
# echo "Recolectando archivos estáticos..."
# python3 manage.py collectstatic --noinput
# echo "Post-deploy completado."
